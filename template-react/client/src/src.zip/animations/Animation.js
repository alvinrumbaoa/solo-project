export const animationOne ={
    in:{
        opacity:1
    },
    out:{
        opacity: 0
    }

};

export const transition = {
    duration: 0.3
}

export const transition2 = {
    duration: 0.9
}

export const transition3 = {
    duration: 1.3
}

export const transition4 = {
    duration: 1.7
}


